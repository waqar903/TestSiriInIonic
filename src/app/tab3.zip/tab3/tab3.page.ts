import { Component } from '@angular/core';
import { SiriShortcuts, SiriShortcut } from '@ionic-native/siri-shortcuts/ngx';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page {

  constructor(private siriShortcuts: SiriShortcuts) {}
  addShortcut(cmd: string) {
    this.siriShortcuts.present({
        persistentIdentifier: 'open-my-app-' + cmd,
        title: 'Open ' + cmd,
        suggestedInvocationPhrase: 'Open ' + cmd,
        userInfo: { command: cmd },
    })
.then(() => console.log('Shortcut added.'))
.catch((error: any) => console.error(error));
}
}
